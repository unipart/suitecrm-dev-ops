<?php
if (!defined('sugarEntry')) {
    define('sugarEntry', true);
}
require_once __DIR__.'/../core/app.php';
