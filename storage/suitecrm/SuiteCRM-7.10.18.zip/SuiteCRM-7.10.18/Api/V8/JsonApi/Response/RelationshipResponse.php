<?php
namespace Api\V8\JsonApi\Response;

class RelationshipResponse extends MetaResponse
{
}
